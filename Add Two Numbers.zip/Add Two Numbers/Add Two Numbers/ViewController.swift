//
//  ViewController.swift
//  Add Two Numbers
//
//  Created by Ignacio Illanes on 28/11/17.
//  Copyright © 2017 Ignacio Illanes. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        Label1.isHidden = true
        self.TextField1.delegate = self
        self.TextField2.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var TextField1: UITextField!
    @IBOutlet weak var TextField2: UITextField!
    @IBOutlet weak var Label1: UILabel!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //This action adds the two numbers
    @IBAction func AddButtonAction(_ sender: Any) {
        Label1.isHidden = false
        let firstValue = Double(TextField1.text!)
        let secondValue = Double(TextField2.text!)
        //it verifies if textfields are with numbers
        if(firstValue != nil && secondValue != nil){
           let outputValue = Double(firstValue! + secondValue!)
            Label1.text = "\(outputValue)"
        }else{
            //otherwise it displays a message
            Label1.text = "You must enter a number"
        }
    }
    //this action clears all the text fields & the label that is used for displaying the answer
    @IBAction func ClearButtonAction(_ sender: Any) {
        Label1.text = " "
        TextField1.text = " "
        TextField2.text = " "
    }
    
    //hide the keyboard when user touches outside the keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        self.view.endEditing(true)
    }
    
}

